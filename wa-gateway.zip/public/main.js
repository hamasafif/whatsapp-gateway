/* ----------  CEK TOKEN  ---------- */
const token = localStorage.getItem('token');
if (!token) {
  location.href = '/login';
}

/* ----------  FUNGSI UMUM  ---------- */
function logout() {
  localStorage.removeItem('token');
  location.href = '/login';
}

function scrollToId(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}

function log(msg) {
  const box = document.getElementById('log');
  box.textContent = `[${new Date().toLocaleTimeString()}] ${msg}\n` + box.textContent;
}

/* ----------  KIRIM PESAN  ---------- */
async function send(type) {
  const number = document.getElementById('number').value;
  const text   = document.getElementById('text').value;
  const body   = { number, message: text, type };

  if (type === 'poll') {
    const values = prompt('Pilihan polling (pisah koma):', 'Ya,Tidak').split(',');
    body.options = { values };
  }

  if (type === 'image') {
    const file = document.getElementById('file').files[0];
    if (!file) return alert('Pilih gambar dulu');
    body.options = { path: file.path };
  }

  try {
    const res = await fetch('/send', {
      method : 'POST',
      headers: {
        'Content-Type' : 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(body)
    });
    const out = await res.json();
    log(`Kirim: ${out.success ? 'ok' : out.error}`);
  } catch (e) {
    log('Gagal kirim: ' + e.message);
  }
}

/* ----------  BROADCAST  ---------- */
async function broadcast() {
  const nums = document.getElementById('bcnumbers').value.split(',').map(v => v.trim());
  const msg  = document.getElementById('bcmsg').value;

  try {
    const res = await fetch('/broadcast', {
      method : 'POST',
      headers: {
        'Content-Type' : 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ numbers: nums, message: msg, delay: 3000 })
    });
    const out = await res.json();
    log(`Broadcast: ${out.results.length} pesan`);
  } catch (e) {
    log('Gagal broadcast: ' + e.message);
  }
}

/* ----------  POLLING STATUS & QR  ---------- */
setInterval(async () => {
  try {
    const res  = await fetch('/qr', { headers: { 'Authorization': `Bearer ${token}` } });
    const data = await res.json();
    const qrBox = document.getElementById('qrbox');

    if (data.qr) {
      qrBox.classList.remove('hidden');
      const canvas = document.getElementById('qrcanvas');
      const img    = new Image();
      img.onload   = () => {
        canvas.width  = img.width;
        canvas.height = img.height;
        canvas.getContext('2d').drawImage(img, 0, 0);
      };
      img.src = data.qr;
    } else {
      qrBox.classList.add('hidden');
    }
  } catch (e) {
    console.warn('Gagal polling QR:', e.message);
  }
}, 3000);

setInterval(async () => {
  try {
    const res  = await fetch('/status', { headers: { 'Authorization': `Bearer ${token}` } });
    const data = await res.json();
    document.getElementById('status').textContent = data.online ? '✅ Online' : '❌ Offline';
  } catch (e) {
    console.warn('Gagal polling status:', e.message);
  }
}, 5000);

/* ----------  HAPUS SESSION (TOMBOl)  ---------- */
async function deleteSession() {
  if (!confirm('Yakin hapus session? WA akan logout & QR muncul kembali.')) return;
  try {
    log('Menghapus session…');
    const res = await fetch('/session', {
      method : 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const out = await res.json();
    log(out.success ? 'Session terhapus – tunggu QR baru' : out.error);

    // opsional: sembunyikan QR lama & tampilkan status
    document.getElementById('qrbox').classList.add('hidden');
    document.getElementById('qrstatus').textContent = 'Menghubungkan…';
  } catch (e) {
    log('Gagal hapus session: ' + e.message);
  }
}

/* ----------  PASANG LISTENER SETELAH DOM SIAP  ---------- */
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('delSessionBtn');
  if (btn) {
    btn.addEventListener('click', deleteSession);
  } else {
    console.error('Elemen #delSessionBtn tidak ditemukan');
  }
});