// server.js
import express from 'express';
import makeWASocket, { DisconnectReason, useMultiFileAuthState } from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import jwt from 'jsonwebtoken';
import cors from 'cors';
import qrcode from 'qrcode';
import fs from 'fs';
import { rmSync } from 'node:fs';
import path from 'path';
import { auth, JWT_SECRET } from './auth.js';

const app  = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));
const PORT = 5001;

let sock;
let qrBase64;
const savedSessions = './sessions';

function isWAConnected() {
  return sock && sock.user && sock.user.id ? true : false;
}

/* ----------  WEBHOOK  ---------- */
const webhookURL = process.env.WEBHOOK_URL || 'https://n8n.wrjunior.my.id/webhook-test/wa-in';

async function sendWebhook(data) {
  try {
    await fetch(webhookURL, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(data)
    });
  } catch (e) {
    console.log('❌ Webhook gagal:', e.message);
  }
}

/* ----------  BAILEYS  ---------- */
async function connectWA() {
  const { state, saveCreds } = await useMultiFileAuthState(savedSessions);
  sock = makeWASocket({ auth: state, printQRInTerminal: false });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) qrBase64 = await qrcode.toDataURL(qr);
    if (connection === 'open') {
      qrBase64 = null;
      console.log('✅ WhatsApp connected');
    } else if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log('❌ connection closed', shouldReconnect ? 'reconnecting...' : '');
      if (shouldReconnect) setTimeout(connectWA, 3000);
    }
  });

  sock.ev.on('messages.upsert', async (m) => {
    const msg = m.messages[0];
    if (!msg.key.fromMe && msg.message) {
      const type = getMessageType(msg.message);
      const cleanNumber = msg.key.remoteJid.replace('@s.whatsapp.net', '');
      await sendWebhook({
        rawJid    : msg.key.remoteJid,
        from      : cleanNumber,
        name      : msg.pushName || 'Unknown',
        messageId : msg.key.id,
        type      : type.type,
        text      : type.text,
        caption   : type.caption,
        mediaUrl  : type.mediaUrl,
        timestamp : new Date().toISOString()
      });
    }
  });

  function getMessageType(msg) {
    if (msg.conversation) return { type: 'text', text: msg.conversation, caption: '', mediaUrl: '' };
    if (msg.imageMessage)  return { type: 'image', text: msg.imageMessage.caption || '', caption: msg.imageMessage.caption || '', mediaUrl: msg.imageMessage.url || '' };
    if (msg.videoMessage)  return { type: 'video', text: msg.videoMessage.caption || '', caption: msg.videoMessage.caption || '', mediaUrl: msg.videoMessage.url || '' };
    if (msg.audioMessage)  return { type: 'audio', text: '', caption: '', mediaUrl: msg.audioMessage.url || '' };
    if (msg.documentMessage) return { type: 'document', text: msg.documentMessage.caption || '', caption: msg.documentMessage.caption || '', mediaUrl: msg.documentMessage.url || '' };
    if (msg.stickerMessage) return { type: 'sticker', text: '', caption: '', mediaUrl: msg.stickerMessage.url || '' };
    return { type: 'unknown', text: '', caption: '', mediaUrl: '' };
  }
}
connectWA();

/* ----------  ROUTING  ---------- */
app.get('/login', (_, res) => res.sendFile(path.resolve('public/login.html')));
app.get('/',   auth, (_, res) => res.sendFile(path.resolve('public/index.html')));

/* ----------  API  ---------- */
app.post('/login', (req, res) => {
  const { user, pass } = req.body;
  if (user === 'wrjunior' && pass === 'Hamas@fif13') {
    const token = jwt.sign({ user }, JWT_SECRET, { expiresIn: '7d' });
    return res.json({ token });
  }
  res.status(401).json({ error: 'invalid creds' });
});

app.get('/qr',     auth, (_, res) => res.json({ qr: qrBase64 }));
app.get('/status', auth, (_, res) => res.json({ online: isWAConnected() }));

app.post('/send', auth, async (req, res) => {
  try {
    const { number, message, type = 'text', options } = req.body;
    const jid = number.includes('@') ? number : `${number}@s.whatsapp.net`;
    let sent;
    if (type === 'text') {
      sent = await sock.sendMessage(jid, { text: message });
    } else if (type === 'image') {
      const buffer = fs.readFileSync(options.path);
      sent = await sock.sendMessage(jid, { image: buffer, caption: message });
    } else if (type === 'poll') {
      sent = await sock.sendMessage(jid, { poll: { name: message, values: options.values } });
    } else return res.status(400).json({ error: 'unsupported type' });
    res.json({ success: true, id: sent.key.id });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/broadcast', auth, async (req, res) => {
  const { numbers, message, delay = 3000 } = req.body;
  const results = [];
  for (const num of numbers) {
    try {
      const jid = num.includes('@') ? num : `${num}@s.whatsapp.net`;
      const sent = await sock.sendMessage(jid, { text: message });
      results.push({ num, status: 'ok', id: sent.key.id });
    } catch (e) {
      results.push({ num, status: 'fail', error: e.message });
    }
    await new Promise(r => setTimeout(r, delay));
  }
  res.json({ results });
});

/*  HAPUS SESSION  */
app.delete('/session', auth, (req, res) => {
  try {
    if (sock && sock.user) sock.logout();
    else if (sock) sock.end();
    sock = null; qrBase64 = null;
    rmSync(savedSessions, { recursive: true, force: true });
    res.json({ success: true, msg: 'Session dihapus' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log(`🚀 Server & Baileys ready on http://localhost:${PORT}`));