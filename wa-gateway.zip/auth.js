import jwt from 'jsonwebtoken';
const JWT_SECRET = 'CAYfnXKSPlFLGjo8dcsxroUtk5ZcjVpW9sm6f67LcYl2wwFsyKQI5ex4/+/l63Ze';

export function auth(req, res, next) {
  const hdr = req.headers['authorization'];
  if (!hdr) return res.redirect('/login');
  const token = hdr.split(' ')[1];
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.redirect('/login');
  }
}

export { JWT_SECRET };